import cv2
import numpy as np
from oneai.common.utils.common_utility import CommonUtil
points = []


def mouse_callback(event, x, y, flags, param):
    if event == cv2.EVENT_LBUTTONDOWN:
        print("point:=", x, y)
        points.append(x)
        points.append(y)


if __name__ == '__main__':
    cap = cv2.VideoCapture(0)

    width = 320
    height = 240
    cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
    cap.set(cv2.CAP_PROP_FPS, 30)

    fx = 259.4841
    cx = 162.5075
    fy = 259.5254
    cy = 118.7996
    k1, k2, p1, p2, k3 = -0.3399, 0.1552, 0.00082795, 0.00068347, -0.0500

    # 相机坐标系到像素坐标系的转换矩阵
    k = np.array([
        [fx, 0, cx],
        [0, fy, cy],
        [0, 0, 1]
    ])
    # 畸变系数
    d = np.array([
        k1, k2, p1, p2, k3
    ])
    matrix = CommonUtil.get_ini_param("camera", "matrix")
    coef = CommonUtil.get_ini_param("camera", "coef")
    matrix = np.fromstring(matrix, dtype=float, sep=' ')
    matrix = np.reshape(matrix, (3, 3))
    coef = np.fromstring(coef, dtype=float, sep=' ')
    print("matrix:{},coef:{}，请依次点击左上角/ 右上角/ 左下角/ 右下角", matrix, coef)
    mapx, mapy = cv2.initUndistortRectifyMap(matrix, coef, None, matrix, (width, height), 5)

    cv2.namedWindow('capture')
    cv2.setMouseCallback('capture', mouse_callback)
    while (1):
        # get a frame
        ret, frame = cap.read()
        dist_frame = cv2.remap(frame, mapx, mapy, cv2.INTER_LINEAR)
        cv2.line(dist_frame, (width//2, 0), (width//2, height), (0, 255, 0), 1)
        # show a frame
        cv2.imshow("capture", dist_frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    perspective = np.array(points)
    CommonUtil.set_ini_camera_perspective(perspective)
    print(perspective)

